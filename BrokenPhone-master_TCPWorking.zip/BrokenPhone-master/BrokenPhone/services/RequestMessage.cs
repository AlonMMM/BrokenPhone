﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokenPhone.services
{
    class RequestMessage : Message
    {


        public RequestMessage()
        {
                
        }
    }
}
